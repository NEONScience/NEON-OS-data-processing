library(testthat)
library(neonOS)

test_check("neonOS")